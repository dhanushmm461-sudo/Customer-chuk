<div align=center>
  <h1>Discord Chatbot</h1> <br>
  
  <a href="https://discord.gg/dcdev"><img src="https://img.shields.io/discord/708565122188312579?color=5865F2&logo=discord&logoColor=white" alt="Discord server" /></a>
  
  <a href="https://github.com/discordjs">
    <img src="https://img.shields.io/badge/discord.js-v13.6.0-blue.svg?logo=npm" alt="discordjs">
  </a>

  <a href="https://github.com/diwasatreya/Chatbot/blob/main/LICENSE">
    <img src="https://img.shields.io/badge/license-Apache%202-blue" alt="license">
  </a>

</div>

# Features 
- Multi Guild
- AI
- Can speak in all languages
- Made specially for discord

# Setup
- Click Star and Folk this Code

    ![image](https://user-images.githubusercontent.com/74746579/131488961-1768f9ea-edc1-43aa-9fa3-b3c2976aee09.png)

- After doing star and fork click run on replit
  
    [![image](https://camo.githubusercontent.com/807ef293459e367b2769d7b590e00f31e35d6b2e1c7bc4f570e37abbc3650f3c/68747470733a2f2f7265706c2e69742f62616467652f6769746875622f5a65726f446973636f72642f4769766561776179426f74)](https://repl.it/github/diwasatreya/Chatbot)

# Installization
- Update your node version for replit users 

- ```npm i --save-dev node@latest && npm config set prefix=$(pwd)/node_modules/node && export PATH=$(pwd)/node_modules/node/bin:$PATH```
- Run `npm install` in console or shell
- Add prefix and developer name in `config.json`
- Add TOKEN in `.env` file or for replit user in secrets 

